# OpenMP CFG Generation Pipeline

LLM-based Control Flow Graph generation for OpenMP parallel code analysis.

## 🚀 Quick Start

1. **Run the setup script:**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

2. **Generate a CFG for SparseLU:**
   ```bash
   cd scripts
   python3 cfg_generator.py --input ../bots/omp-tasks/sparselu/sparselu_for/sparselu.c
   ```

3. **Check the results:**
   ```bash
   ls ../output/
   ```

## 📁 Project Structure

```
openmp-cfg-project/
├── scripts/                     # Main scripts
│   ├── cfg_generator.py         # Single file CFG generation
│   └── batch_process.py         # Batch process all benchmarks
├── configs/                     # Configuration files
│   └── hardware_specs.json     # Hardware target specifications
├── docs/                        # Documentation
├── output/                      # Generated CFGs (created after first run)
├── bots/                        # BOTS repository (cloned by setup.sh)
├── requirements.txt             # Python dependencies
├── setup.sh                     # Automated setup script
└── README.md                    # This file
```

## 🔧 Features

- **Automatic OpenMP Detection**: Identifies parallel regions, tasks, loops, and synchronization
- **Smart CFG Generation**: Context-aware graph generation based on detected patterns
- **Multiple Output Formats**: DOT files and PNG visualizations
- **Batch Processing**: Process all BOTS benchmarks at once
- **Hardware Awareness**: Configurable target architecture specifications
- **Comprehensive Validation**: Built-in CFG quality checks

## 📊 Supported OpenMP Constructs

- `#pragma omp parallel` - Parallel regions
- `#pragma omp task` - Task creation (tied/untied)
- `#pragma omp for` - Parallel for loops
- `#pragma omp single` - Single execution regions
- `#pragma omp barrier` - Explicit synchronization
- Implicit barriers and synchronization points

## 🎯 Usage Examples

### Single File Processing
```bash
# Basic usage
python3 cfg_generator.py --input ../bots/omp-tasks/sparselu/sparselu_for/sparselu.c

# With custom hardware specs
python3 cfg_generator.py --input ../bots/omp-tasks/fft/fft.c --cores 16 --arch x86_64

# With custom output directory
python3 cfg_generator.py --input ../bots/omp-tasks/nqueens/nqueens.c --output /path/to/output
```

### Batch Processing
```bash
# Process all BOTS benchmarks
python3 batch_process.py
```

## 📈 Expected Output

After running the CFG generator, you'll find:

- **`benchmark_cfg.dot`** - Machine-readable CFG in DOT format
- **`benchmark_cfg.png`** - Visual representation (if Graphviz is installed)
- **Console output** - Detected constructs and validation results

## 🔍 Validation Checks

The pipeline automatically validates generated CFGs:

- ✅ **Entry/Exit Points**: Proper graph boundaries
- ✅ **Parallel Regions**: Detection and annotation
- ✅ **Task Constructs**: Task creation and execution
- ✅ **Synchronization**: Barriers and sync points
- ✅ **DOT Syntax**: Valid Graphviz format
- ✅ **Control Flow**: Proper edge connections

## 🛠️ Requirements

### System Dependencies
- Python 3.8 or higher
- Git
- Graphviz (optional, for PNG generation)

### Python Packages
- matplotlib (visualization)
- networkx (graph processing)
- graphviz (DOT format handling)
- numpy (numerical operations)
- openai (optional, for real LLM integration)

## 🔧 Configuration

### Hardware Specifications
Edit `configs/hardware_specs.json` to define target architectures:

```json
{
    "custom_config": {
        "cores": 24,
        "arch": "x86_64",
        "memory": "48GB"
    }
}
```

### LLM Integration (Optional)
For enhanced results with real LLM APIs:

```bash
export OPENAI_API_KEY=your_api_key_here
python3 cfg_generator.py --input file.c --api-key $OPENAI_API_KEY
```

## 🐛 Troubleshooting

### Common Issues

**"BOTS repository not found"**
- Run `./setup.sh` to clone the repository
- Ensure you have internet connectivity

**"Graphviz not found"**
- Install: `sudo apt install graphviz` (Linux) or `brew install graphviz` (macOS)
- PNG generation will be skipped if not available

**"Permission denied"**
- Make scripts executable: `chmod +x setup.sh scripts/*.py`

**"No OpenMP constructs found"**
- Verify the input file contains `#pragma omp` directives
- Check file encoding (should be UTF-8)

## 📚 Research Context

This pipeline was developed to support research in:
- Automated parallel program analysis
- LLM-based code understanding
- Performance optimization through CFG analysis
- OpenMP program variant comparison

## 🤝 Contributing

To extend the pipeline:
1. Add new CFG patterns in `cfg_generator.py`
2. Extend validation checks for new constructs
3. Add support for additional OpenMP directives
4. Improve visualization layouts

## 📄 License

This project is part of academic research. Please cite appropriately if used in publications.

## 🎯 Next Steps

1. **Test the pipeline** with provided examples
2. **Customize hardware specs** for your target system
3. **Integrate with LLM APIs** for enhanced results
4. **Extend to your own benchmarks** beyond BOTS
5. **Compare results** with existing tools like OmpTG

Happy CFG generation! 🚀

