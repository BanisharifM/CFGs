#!/bin/bash
echo "🚀 Setting up LLM-based CFG Generation Pipeline..."

# Create directories
mkdir -p output

# Install system dependencies
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "📦 Installing system dependencies for Linux..."
    sudo apt update && sudo apt install -y python3 python3-pip git graphviz
elif [[ "$OSTYPE" == "darwin"* ]]; then
    echo "📦 Installing system dependencies for macOS..."
    if command -v brew &> /dev/null; then
        brew install python3 git graphviz
    else
        echo "❌ Homebrew not found. Please install Homebrew first."
        exit 1
    fi
fi

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip3 install -r requirements.txt

# Clone BOTS repository
echo "📥 Cloning BOTS repository..."
if [ ! -d "bots" ]; then
    git clone https://github.com/bsc-pm/bots.git
    echo "✅ BOTS repository cloned successfully"
else
    echo "ℹ️  BOTS repository already exists"
fi

# Check installation
echo "🔍 Verifying installation..."
python3 --version
git --version

if command -v dot &> /dev/null; then
    echo "✅ Graphviz installed: $(dot -V 2>&1)"
else
    echo "⚠️  Graphviz not found - PNG generation will not work"
fi

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. cd scripts"
echo "2. python3 cfg_generator.py --input ../bots/omp-tasks/sparselu/sparselu_for/sparselu.c"
echo "3. Check results in ../output/"
echo ""
echo "💡 Optional: Set OpenAI API key for better results:"
echo "   export OPENAI_API_KEY=your_api_key_here"

